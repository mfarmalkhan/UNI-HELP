<?php

session_start();



header('location:loginandregister.php');

include 'connection.php';

$email = $_POST['email'];
$pass = $_POST['password'];
$fullname = $_POST['fullname'];

$pass = md5("$pass");

$query1 = "Select * from user where User_Email = '$email' && user_password = '$pass';";

$result = mysqli_query($conn,$query1);

$num = mysqli_num_rows($result);

if ($num == 1) {
    $_SESSION['email'] = $email;
    //header('location:SearchPage.php');
    header("Location: Homepage.php");
}
else {
    echo '<script language="javascript">';
    echo 'if (confirm("Invalid credentials!")) {
            window.location.href = "loginandregister.php";
            }';
    echo '</script>';
        }
?>
