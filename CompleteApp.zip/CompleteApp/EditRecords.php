<?php

include 'connection.php';

?>

<html>

<head> 
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>

    <div class = container>

<h2>EDIT PROJECT RECORDS</h2> <br><br>

<ul style="list-style-type:disc">
  <li href = "EditUni.php">UPDATE UNIVERSITIES</li><br><br>
  <li>UPDATE FIELDS</li><br><br>
  <li>UPDATE PROGRAMS</li><br><br>
</ul>  

<button class="btn btn-primary" href = "AdminPanel.php"> Log Out </button> <br> <br>

</div>

</body>
</html>