<?php

include 'connection.php';
//session_start();

//$userEmail = $_POST['userEmail']; //retreive user's email
$subject = $_POST['subject'];
$message = $_POST['message'];
$userName = $_POST['userName'];

//$userEmail = $_SESSION['email']; //retreive user's email
//$userPassword = $_SESSION['userpass']; //retrieve user's password

require 'PHPMailer\PHPMailerAutoload.php';

$mail = new PHPMailer;

//$mail->SMTPDebug = 2;
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'contactunihelp@gmail.com';                 // SMTP username
$mail->Password = 'customersupport';                           // SMTP password
$mail->SMTPSecure = 'ssl';                            // Enable encryption, 'ssl' also accepted
$mail->Port = 465;
$mail->isHTML(true);

//$mail->setFrom("$userEmail","$userName");
$mail->addAddress('uni.help222@gmail.com', 'UNI-HELP');     // Add a recipient
$mail->WordWrap = 50;

$mail->FromName = "$userName";

//$mail->addAttachment('C:\Users\Asad Amir\Downloads\A.mp4');         // Add attachments
//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

$mail->Subject = "$subject";
$mail->Body    = "$message";

if(!$mail->send()) {
    echo '<script language="javascript">';
    echo 'if (confirm("Message could not be sent. Please try later")) {
            window.location.href = "Homepage.php";
            }';
    echo '</script>';
} else {
    echo '<script language="javascript">';
    echo 'if (confirm("Message sent, we will contact you shortly.")) {
            window.location.href = "Homepage.php";
            }';
    echo '</script>';
}
?>
