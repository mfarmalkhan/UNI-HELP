<?php

include 'connection.php';


session_start();

if (!isset($_SESSION['email'])) {
    header('location:../loginandregister.php');
}

?>

<html>
    <head> 
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

  <style>
      @import url('https://fonts.googleapis.com/css?family=Roboto+Slab');
.container{
    width: 350px;
    height: 390px;
    background: #000;
    color: #fff;
    top: 50%;
    left: 50%;
    position: absolute;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 50px 70px;
    opacity: 0.8;
    border-radius: 20px;
    
      }
      .container
      .btn-wrap{
          padding: 8px;
          text-align: center;
      }
      .container .btn btn-primary{
          position: absolute;
          top: 80%;
          left:370px;
          opacity: 0.9;
      }
      .container h1{
          font-family: 'Roboto Slab', serif;
          color: bisque;
          
      }

body {
background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)),  url('searchback.png');
}

  </style>
    </head>

    <title>Find University</title>
    
        <body>

        <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <ul class="nav navbar-nav navbar-right">
      <li><a href="Homepage.php"><span class="glyphicon glyphicon-home"></span>  HOME</a></li>
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> LOG OUT</a></li>
      </ul>
    </div>
         </nav>
        <div class="container">

        
        
        <form action = "ProgAndLevel.php" method = "GET">    
                <h1>Select Field</h1>
<div class="custom-select" style="width:200px;">
            <select name = "fieldOptions" class = "form-control">
            <option value = "Select Field_Name from fields" selected> Select Field </option>
            <?php include 'connection.php'; 
            $query = "Select * from fields;";

            $result = mysqli_query($conn,$query);
          ?>

            <?php while ($row = mysqli_fetch_array($result)):; ?>
            <option value = "<?php echo $row['Field_Name'];?>"> <?php echo $row['Field_Name']; ?> </option>
            <?php endwhile; ?>
                    
                </select>
            </div>
                
                
                <h1>Select City</h1>
            <div class="custom-select" style="width:200px;" >
                <select name = "cityOptions" class = "form-control">
                <option value = "Select City_Name from university" selected> Select City </option>
                <?php include 'connection.php'; 
                $query = "Select distinct City_Name from university;";

                $result = mysqli_query($conn,$query);


                 while ($row = mysqli_fetch_array($result)):; ?>
                <option value = "<?php echo $row['City_Name'];?>"> <?php echo $row['City_Name'];?> </option>
                <?php endwhile; ?>

                </select>
            </div><br>
            <div class="btn-wrap">
            <button type = "submit" class="btn btn-primary"> Search </button>
                </div>
            <br> <br>
            
                
            </form>         

        
        </div>
        
    </body>

</html>

