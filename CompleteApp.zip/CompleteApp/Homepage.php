<?php

include 'connection.php';


session_start();

if (!isset($_SESSION['email'])) {
    header('location:loginandregister.php');
}

?>
<html>
    <head>
    <title>
        Homepage
    </title>
    <link rel="stylesheet" type="text/css" href="Homepage.css">
    <script src="index.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Karla" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.bundle.min.js" integrity="sha384-pjaaA8dDz/5BgdFUPX6M/9SUZv4d12SUPF0axWc+VRZkx5xU3daN+lYb49+Ax+Tl" crossorigin="anonymous"></script>
    </head>
    <body>
        <nav class="navbar navbar-dark navbar-inverse">
            
  <div class="container-fluid">
        <div class="toggle-btn" onclick="toggleSidebar(this)">
                <span></span>
                <span></span>
                <span></span>
                </div>
    <div class="navbar-header">
            <div class="navbar-text">
                    UNI-HELP
                </div>
          
          
      </a>
        
       
            
    </div>
  </div>
</nav>
        
    
        <div id="sidebar">
            <div class="toggle-btn" onclick="toggleSidebar(this)">
            <span></span>
            <span></span>
            <span></span>
            </div>
            <div id="sidebar-brand">
            <img src="owl.jpg" height="200" width="200">
                <br>
                <br>
            </div>
            
        <div class="list">
            <div class="item"><a href="SearchPage.php"><span class="glyphicon glyphicon-search"></span> Find University</a></div>
            <div class="item"><a href="AboutUs.php">About</a></div>
            <div class="item"><a href="Contact.php">Contact us</a></div>
            
            <div class="item"><a href="Favourite.php">Favourites</a></div>
            <div class="item"><a href="logout.php">Log out</a></div>
        </div>
        </div>
        <div class="box">
            <h1>RECENT NEWS/UPDATES</h1>

            <marquee direction="down" scrollamount="3" behaviour="scroll" hspace="10%" vspace="5%">
            
            <p>Admissions for IBA are now open for SPRING 2019!, Programme offered: BBA,EM,ACF,SS.</p>
            <br>
            <p>GOOD NEWS! IBA test now have zero negative marking. APPLY NOW</p>
            <br>
            <p>LUMS is now taking admissions for SPRING 2019</p>
            <br>
            <p>IBA moves up in the ranking, 25th in the national ranking.</p>
            <br>
            <p>IoBM introduces a new field, BS in Accounting&law.</p>
            <br>
            <p>IBA has the best international faculty: EXPRESS TRIBUNE</p>
            <br>
            <p>IBA introduces a new undergrad programme, BS ECONOMICS.</p>
            <br>
            <p>To get the latest updates, contact us at uni.help222@gmail.com</p>
            <br>
            
            </marquee>
            
            </div>        

    </body>
</html>