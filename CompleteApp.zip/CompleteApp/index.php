<?php
 header('location:../CompleteApp/loginandregister.php');


?>