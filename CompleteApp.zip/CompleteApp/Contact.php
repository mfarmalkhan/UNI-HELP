<?php

include 'connection.php';


session_start();

if (!isset($_SESSION['email'])) {
    header('location:loginandregister.php');

    $userEmail = $_SESSION['email']; //retreive user's email
    $userPassword = $_SESSION['pass1']; //retrieve user's password

}
?>

<html>
    <head>
        <title>
        Contact
            </title>
            
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 	
 	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
        body{
    margin: 0;
    padding: 0;
    background: url(back1.jpg);   
    background-size: cover;
    background-position: center;
    font-family: sans-serif;
}

.contactbox{
    width: 350px;
    height: 500px;
    background: #000;
    color: #fff;
    top: 50%;
    left: 50%;
    position: absolute;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 70px 30px;
}
h1{
    margin:0;
    padding: 0 0 20px;
    text-align: center;
    font-size: 22px;
    font-family: monospace;
    }
label{
    margin:0;
    padding: 0;
    font-weight: bold;
    font-family:monospace;
}
.contactbox input{
    width:100%;
    margin-bottom: 20px;
    
}
.contactbox input[type="text"],input[type="email"]{
    border : none;
    border-bottom: 1px solid red;
    border-top: #000;
    border-left: #000;
    border-right: #000;
    background: transparent;
    outline: none;
    height: 40px;
    color: #fff;
    font-size: 16px;
    
    
}
.contactbox
input[type="submit"]
{
    margin-top: 5px;
    border: none;
    outline: none;
    height: 40px;
    background: #fb2525;
    color:#fff;
    font-size: 18px;
    border-radius: 20px;
    
}
.contactbox input[type="submit"]:hover{
    cursor: pointer;
    background: #ffc107;
    color: #000;
    
}
.contactbox 
input[type="button"]{
    margin-top: 5px;
    border: none;
    outline: none;
    height: 40px;
    background: #fb2525;
    color:#fff;
    font-size: 18px;
    border-radius: 20px;
    
}
.contactbox input[type="button"]:hover{
    cursor: pointer;
    background: #ffc107;
    color: #000;
    
}
        </style>
    <body>
        <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <ul class="nav navbar-nav navbar-right">
      <li><a href="Homepage.php"><span class="glyphicon glyphicon-home"></span>  HOME</a></li>
      <li><a href="Favourite.php"><span class="glyphicon glyphicon-heart-empty"></span> FAVOURITES</a></li>
      </ul>
    </div>
        </nav>
        

        <div class="contactbox">
            <h1>Contact Us</h1>

        <form action = "sendMessage.php" method = "POST">
           
        <label>Your Name</label>
    
      <input type="text" name="userName" required>        

            <label>Subject</label>
    
      <input type="text" name="subject" required>           
                
            <label>Message</label>
    
      <input type="text" name="message" required> <br><br>

      <input type="submit" value="Send">
        <a href="Homepage.php">
   <input type="button" value="Go Back"  href = "Homepage.php"/>
</a>            
            
        </form>
            
        </div>
         
    </body>
    </head>
</html>