<html>
<head> 
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <style>
        @import url('https://fonts.googleapis.com/css?family=Barlow');

    body {
background-image: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)),url('favor.jpg');
        
}
        .container{
            top:50%;
            left:39%;
        }
        .container h1{
            font-family: 'Barlow', sans-serif;
            color: bisque;
            font-size=40;
        }

    </style>

    </head>
    <body>
        <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <ul class="nav navbar-nav navbar-right">
      <li><a href="Homepage.php"><span class="glyphicon glyphicon-home"></span>  HOME</a></li>
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> LOG OUT</a></li>
      </ul>
    </div>
        </nav>

<?php 

    session_start();

    include_once 'connection.php';

    if (!isset($_SESSION['email'])) {
        header('location:../CompleteApp/loginandregister.php');
    }

    $email = $_SESSION['email'];


?>
<div class = "container">

<br><br><br><br>

<h1> Your Favourites</h1> <br>

<table class = "table table-bordered">
    <tr class="bg-primary">
        <th>Program Name </th>
        <th>University Name </th>
        <th>Visited On </th>
        <th>Remove </th>
           
<?php

//$query2 = "SELECT u.Ranking, u.UNI_Name, f.Field_Name from field_offered b JOIN university u on b.UNI_ID = u.UNI_ID JOIN fields f ON b.FID = f.FID where Field_Name = '$fieldname' AND City_Name = '$cityname';";
$query2 = "SELECT * from saved_data where User_Email = '$email';";

$result = mysqli_query($conn,$query2);
$resultCheck = mysqli_num_rows($result);

if ($resultCheck > 0) {
while ($row = mysqli_fetch_assoc($result)) {
echo "<tr class=bg-success><td>" . $row["Prog_Name"] . "</td><td>" . $row["UNI_Name"] . "</td><td>". $row["saved_on"]. "</td><td>". '<a class = "btn btn-danger" href="DeleteProg.php?id='.$row['sid'].'"> Delete </a>'. "</td></tr>";
}
echo "</table>";
}
else {

//echo "No data found";
//header('location:SearchPage.php');
}

?>
</table>

</div>

</body>
</html>
