<!DOCTYPE html>
 <html lang="en">
 <head>
 	<meta charset="UTF-8">
 	<title>About Us</title>
 	
 	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 	
 	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 	<script src="../StyleApp/index.js"></script>
 	<style>
        
        @import("C:\Users\AmmarR\Desktop\UNI-HELP\Homepage\style.css");
	    @import url('https://fonts.googleapis.com/css?family=Ubuntu');
        @import url('https://fonts.googleapis.com/css?family=Pacifico');

		body{
			background:url(about-background.jpg);
			font-family: 'Ubuntu', sans-serif;
			text-align: justify;
			overflow: hidden;
		}
        #sidebar {
        position:absolute;
        top:0px;
        left:-200px;
        width:200px;
        height:100%;
        opacity: 0.5;
        transition:all 100ms linear;
}
#sidebar div.list div.item a{
    font-family: sans-serif;
    text-decoration: none;
}
#sidebar div.list div.item a:visited {
  color:white;
  text-decoration:none;
}
#sidebar div.list div.item a:hover{
    color:black;
    border-radius:5px;
    background-color:#ccffff;
    text-decoration: none;
}
#sidebar .toggle-btn {
  position:absolute;
  left:220px;
  top:10px;
}
#sidebar .toggle-btn span {
  display:block;
  width:30px;
  height:5px;
  background:white;
  margin:5px 0px;
  cursor:pointer;
}

#sidebar div.list{
    
padding-top: 6px;
    border-radius: 5px;
    padding-left: 0px;
}

#sidebar div.list div.item {
    
  padding:8px 30px;
  color:#fcfcfc;
  text-transform:uppercase;
  font-size:20px;
}
#sidebar div.list div.button{
    padding:15px 15px;
  
}





body.sidebar-active {
  padding-left:200px;
}
body.sidebar-active #sidebar {
  left:0px;
}
	 
		#about{
			padding-top: 80px;
            

		}
        #about p{
            color: bisque;
            padding: 2px;
        }
        #about .container{
            position: fixed;
            left:450px;
            width: 650px;
            height: 560px;
            padding: 10px;
            
            border-radius: 5px;
            opacity: 0.8;
            
            
        }
        
		#about h2{
            text-align: center;
            font-size: 40px;
			margin-bottom: 45px;
			margin-top: 5px;
            padding-right: 280px;
            font-family: 'Pacifico', cursive;
			
		}
        a{
            color: aliceblue;
        }
		
		
			
		
		
		.color-3{
			color: palegreen;
		}
		p{
			margin-bottom: 2%;
			font-size: 11px;
			line-height: 24px;
			color: antiquewhite;
            font-style: italic;
            
		}
		
		.btn-danger{
			border-radius: 10px;
			padding: 10px 20px;
		}
        .aboutpic{
            position: relative;
            top:150px;
            left: -50px;
            
            
        }
        
		
		
		
	</style>
 	
 	
 </head>
 <body>
     <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <ul class="nav navbar-nav navbar-right">
      <li><a href="Homepage.php"><span class="glyphicon glyphicon-home"></span>  HOME</a></li>
      <li><a href="Favourite.php"><span class="glyphicon glyphicon-heart-empty"></span> FAVOURITES</a></li>
      </ul>
    </div>
        </nav>
 
 	
 	<section id="about">
    
 		
	<div class="container" style="background-color:#000; text-align:left; vertical-align: middle; padding:20px 20px">
		<div class="row">
		<div class="col-md-5">
            <div class="aboutpic">
        <img src="owl.jpg">
        
        
        </div>
			
		</div>
		<br>
		<div class="col-md-7 about-right">
			
			<h2 class="color-3"><b>About</b>
			</h2>
			
			<p>
                Founded in 2018, UNI-HELP represents all the universities across Pakistan, and we are constantly working on expanding our horizons, and become the only online portal for registering and ranking universities. At UNI-HELP, we want our users to experience the ultimate freedom of browsing of universities, without any limitations, in decision-making of the most crucial stage of their career. <b>UNI-HELP</b> is here to provide you the ideal university, <b>anywhere, anytime!</b>
            </p>
            <br>  
            <p>
            At <b>UNI-LIFE</b>, our goal is to not only offer the best available distance learning options, but to match each individual learner with the ideal degree program that fits their specific needs and academic goals. By giving us a brief background about your interest and your educational experience, UNI-LIFE can better identify the perfect degree program that will in future help you land a perfect job or launch a new career.
			</p>
		</div>
	 
		</div>
	</div>
  
 	</section>
 	 
 </body>
 </html>