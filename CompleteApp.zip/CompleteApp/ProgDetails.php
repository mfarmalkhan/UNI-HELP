<html>
    <head> 
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
    <style>
@import url('https://fonts.googleapis.com/css?family=Cuprum');


body {
background-image: linear-gradient(rgba(0, 0, 0, 0.9), rgba(0, 0, 0, 0.9)),  url('searchback.png');
}
.container{
    width: 700px;
    height: 700px;
    
    color: bisque;
    top: 52%;
    left: 50%;
    position: absolute;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 35px 70px;
    opacity: 0.8;
    border-radius: 6px;
    font-family: 'Cuprum', sans-serif;
    font-size: 15px;
    
    }
    
        

</style>

    </head>
    <body>
    <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <ul class="nav navbar-nav navbar-right">
      <li><a href="Homepage.php"><span class="glyphicon glyphicon-home"></span>  HOME</a></li>
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> LOG OUT</a></li>
      </ul>
    </div>
    </nav>
        <div class="container">
        
    
<?php

//echo "This page will display program details";
include_once 'connection.php';

session_start();

    $id = null;

    if(!empty($_GET['id'])){
        $id = $_REQUEST['id']; //selected university

    }

    $progname = $_SESSION['progName']; //selected program

    //retrieve user's email
    $email = $_SESSION['email'];

    //selected level
    //$level = $_SESSION['levelName'];

$searchQuery = "SELECT Adm_Criteria FROM programs p join university u on p.UNI_ID = u.UNI_ID WHERE Prog_Name = '$progname' AND UNI_Name = '$id';";

$result = mysqli_query($conn,$searchQuery);
$resultCheck = mysqli_num_rows($result);

echo "<br><b>". "University Name: ". "$id". "</b><br><br>";
echo "<b>"."Program: ". "$progname"."</b>";

echo "<br><br><br><b>"."Admission Criteria: ". "</b><br><br>";

if ($resultCheck > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        //echo "<br><b>". "University Name: ". "$id". "</b><br><br>";
        //echo "<b>"."Program: ". "$progname"."</b>";

        //print admission criteria
       // echo "<br><br><br><b>"."Admission Criteria: ". "</b><br><br>";
        echo nl2br($row['Adm_Criteria']). "<br>";

    }
}
else {

    //header('location:ProgAndLevel.php');
    echo "Not available";
}

function addToFav() {
    
    include 'connection.php';

    $id = null;

    if(!empty($_GET['id'])){
        $id = $_REQUEST['id']; //selected university

    }

    $progname = $_SESSION['progName']; //selected program

    //retrieve user's email
    $email = $_SESSION['email'];


$querycheck = "SELECT * from saved_data where Prog_Name = '$progname' AND UNI_Name = '$id';";

$result = mysqli_query($conn,$querycheck);

$num = mysqli_num_rows($result);

if ($num == 1) {
    //echo "Program already saved";
    //header('location:ProgDetails.php');
}
else {
   
    $savequery = "INSERT INTO saved_data(User_Email, Prog_Name, UNI_Name, saved_on) VALUES ('$email','$progname', '$id', NOW());";
    mysqli_query($conn,$savequery);
    //header('location:ProgDetails.php');
   }
}

?>
<br><br>
            

<form method="post" action = "#">
    <input class = "btn btn-danger" type="submit" name="btnSave" id="btnSave" value="Add to Favourites" /><br/>
</form>
            
<?php


//add program to favourite

if(array_key_exists('btnSave',$_POST)) {
    addToFav();
     }

?>
        </div>


</body>

</html>