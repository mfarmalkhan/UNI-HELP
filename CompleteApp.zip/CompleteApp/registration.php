<?php

include 'connection.php';

session_start();

$email = $_POST['email'];
$username = $_POST['fullname'];
$pass1 = $_POST['password'];
$pass2 = $_POST['confirmpassword'];

$query = "SELECT * from user where User_Email = '$email';";

$result = mysqli_query($conn,$query);

$num = mysqli_num_rows($result);

if ($num == 1) {
    echo '<script language="javascript">';
    echo 'if (confirm("Email already registered!")) {
            window.location.href = "loginandregister.php";
            }';
    echo '</script>';
    //header('location:loginandregister.php');
}
else if($pass1 !== $pass2) {
    echo '<script language="javascript">';
    echo 'if (confirm("Passwords do not match!")) {
            window.location.href = "loginandregister.php";
            }';
    echo '</script>';
}
else if(strlen($pass1) < 8) {
    echo '<script language="javascript">';
    echo 'if (confirm("Password must be at least 8 characters long!")) {
            window.location.href = "loginandregister.php";
            }';
    echo '</script>';
}
else {

   /* echo '<script language="javascript">';
    echo 'if (confirm("Registration Complete")) {
            window.location.href = "loginandregister.php";
            }';
    echo '</script>';
*/
    
    //encrpyt password
    $pass1  = md5("$pass1");

    $reg = "INSERT into user(User_Name,User_Email,user_password) values ('$username','$email','$pass1');";
    mysqli_query($conn,$reg);
    //echo "Registration Successful";
   // echo '<script language="javascript">';
   // echo 'if (confirm("Registration successfull!")) {
     //       window.location.href = "loginandregister.php";
       //     }';
    //echo '</script>';

//send confirmation email
require 'PHPMailer\PHPMailerAutoload.php';

$mail = new PHPMailer;

//$mail->SMTPDebug = 2;
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'uni.help222@gmail.com';                 // SMTP username
$mail->Password = 'databaseproject';                           // SMTP password
$mail->SMTPSecure = 'ssl';                            // Enable encryption, 'ssl' also accepted
$mail->Port = 465;
$mail->isHTML(true);

//$mail->setFrom("$userEmail","$userName");
$mail->addAddress("$email", "$username");     // Add a recipient
$mail->WordWrap = 50;

$mail->FromName = "UNI-HELP";

//$mail->addAttachment('C:\Users\Asad Amir\Downloads\A.mp4');         // Add attachments
//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

$mail->Subject = "Confirmation of Email";
$mail->Body    = "Thankyou for registering at UNI-HELP!";

if($mail->send()) {
    echo '<script language="javascript">';
    echo 'if (confirm("Registration Complete")) {
            window.location.href = "loginandregister.php";
            }';
    echo '</script>';
} else {
    echo '<script language="javascript">';
    echo 'if (confirm("You may have entered an invalid email address")) {
            window.location.href = "loginandregister.php";
            }';
    echo '</script>';
}

}

?>
