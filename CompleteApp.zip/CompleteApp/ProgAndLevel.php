<html>
<head> 
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<style>
    @import url('https://fonts.googleapis.com/css?family=Bitter');

body {
background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),  url('searchback.png');
}


/* Add media queries for responsiveness - when the screen is 500px wide or less, stack the links on top of each other */ 
@media screen and (max-width: 500px) {
}
.block{
    width: 1300px;
    height: 650px;
    
    color: #fff;
    top: 40%;
    left: 39%;
    position: absolute;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 80px 30px;
    opacity: 0.9;
    border-radius: 4px;
    
      }
    .container h1{
        font-family: 'Bitter', serif;
        color: bisque;
    }
    .container h2{
        font-family: 'Bitter', serif;
        color: beige;
        text-align: center;
        
        
        padding-left: 270px;
    }
    .table-container{
        
        padding-top: 10px;
        padding-left: 310px;
    }

</style>

    </head>
    <body>
        <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <ul class="nav navbar-nav navbar-right">
      <li><a href="Homepage.php"><span class="glyphicon glyphicon-home"></span>  HOME</a></li>
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> LOG OUT</a></li>
      </ul>
    </div>
        </nav>

        <?php 

    session_start();

    include_once 'connection.php';


    $fieldname = $_GET['fieldOptions'];
    $cityname = $_GET['cityOptions'];

   $_SESSION['field'] = $fieldname;
   $_SESSION['city'] = $cityname;

        ?>

       <div class="block">

<div class="container">
        
        <form action = "ThirdResults.php" method = "GET">    
        
        <h1>Select Program</h1>
            <div class="custom-select" style="width:220px;" >
                <select name = "progOptions" class = "form-control">
                <option value = "Select Prog_Name from programs" selected> Select Program </option>
                <?php include 'connection.php'; 
                $query = "Select distinct Prog_Name from programs p join fields f ON p.FID = f.FID where Field_Name = '$fieldname';";

                $result = mysqli_query($conn,$query);

                ?>

                <?php while ($row = mysqli_fetch_array($result)):; ?>
                <option value = "<?php echo $row['Prog_Name'];?>"> <?php echo $row['Prog_Name'];?> </option>
                <?php endwhile; ?>

                </select>
            </div>
                
                <h1>Select Education Level</h1>
            <div class="custom-select" style="width:200px;" >
                <select name = "levelOptions" class = "form-control">
                <option value = "Select distinct Ed_Level from programs" selected> Select Level </option>
                <?php include 'connection.php'; 
                $query = "Select distinct Ed_Level from programs;";

                $result = mysqli_query($conn,$query);
               
                ?>

                <?php while ($row = mysqli_fetch_array($result)):; ?>
                <option value = "<?php echo $row['Ed_Level'];?>"> <?php echo $row['Ed_Level'];?> </option>
                <?php endwhile; ?>

                </select>
            </div>
            <br>

            <button type = "submit" class="btn btn-primary"> Search </button>
            
            
                
            </form>  

             <div class = "container">

            <h2 style="font-size:20px;"><?php  echo "<b>"." Universities offering $fieldname in $cityname "."</b>"; ?> </h1> <br>

            </div>
      
        
        </div>

        <div class = "table-container">

        <table class = "table table-bordered">
            
            <tr class="bg-primary">
                <th>Ranking </th>
                <th>University Name </th>
                
                   
<?php

//$searchQuery = "SELECT Ranking, UNI_Name, Prog_Name FROM programs p join university u ON p.UNI_ID = u.UNI_ID JOIN fields f ON p.FID = f.FID where Field_Name = '$fieldname' AND Prog_Name = '$progname' AND City_Name = '$cityname' AND Ed_Level = '$edlevel';";

$query2 = "SELECT u.Ranking, u.UNI_Name, f.Field_Name from field_offered b JOIN university u on b.UNI_ID = u.UNI_ID JOIN fields f ON b.FID = f.FID where Field_Name = '$fieldname' AND City_Name = '$cityname';";


$result = mysqli_query($conn,$query2);
$resultCheck = mysqli_num_rows($result);

if ($resultCheck > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr><td class=bg-info>" . $row["Ranking"] . "</td><td class=bg-info>" . $row["UNI_Name"] .  "</td></tr>";
    }
    echo "</table>";
}
else {
    
    //echo "No match found";
    echo '<script language="javascript">';
    echo 'if (confirm("No Match Found!")) {
            window.location.href = "SearchPage.php";
            }';
    echo '</script>';
    //header('location:SearchPage.php');
}

?>
</table>

    

</div>
           </div>


</body>
</html>