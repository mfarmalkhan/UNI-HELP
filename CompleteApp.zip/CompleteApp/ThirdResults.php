<html>
<head> 
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <style>
        @import url('https://fonts.googleapis.com/css?family=Titillium+Web');



body {
background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),  url('searchback.png');
}
        .block{
    width: 11px;
    height: 680px;
    
    color: #fff;
    top: 45%;
    left: 15%;
    position: absolute;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 80px 30px;
    opacity: 0.9;
    border-radius: 4px;
            
        }
        .block .container h2{
            font-family: 'Titillium Web', sans-serif;
            text-align: center;
            color: beige;
            margin-top: 15px;
            padding-bottom: 2px;
            padding-top: -10px;
        }



</style>

    </head>
    <body>
        <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <ul class="nav navbar-nav navbar-right">
      <li><a href="Homepage.php"><span class="glyphicon glyphicon-home"></span>  HOME</a></li>
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> LOG OUT</a></li>
      </ul>
    </div>
        </nav>

    

    <?php

    session_start();

    include_once 'connection.php';


    $progname = $_GET['progOptions'];
    $fieldname = $_SESSION['field'];
    $edlevel = $_GET['levelOptions'];
    $cityname = $_SESSION['city'];

    $_SESSION['progName'] = $progname;
    //$_SESSION['levelName'] = $edlevel;

    ?>
<div class="block">
    <div class = "container">

    <h2>Your Search Filters</h2>
        <br>

    <div class = "panel panel-default">

    <div class="list-group-item list-group-item-success"><?php  echo "<b>" . "Field: $fieldname "; ?> </div>
    <div class="list-group-item list-group-item-info"><?php  echo "City: $cityname "; ?> </div>
    <div class="list-group-item list-group-item-warning"><?php  echo "Level: $edlevel "; ?> </div>
    <div class="list-group-item list-group-item-danger"><?php  echo "Program: $progname ". "</b>"; ?> </div>
    

    </div>

    </div>


    <div class = "container">
        <table class="table table-hover table-dark">
            
  <thead>
    <tr class="bg-primary">
      <th scope="col">Ranking</th>
      <th scope="col">University Name</th>
      <th scope="col">Program Name</th>
      <th scope="col">Details</th>
    </tr>
  </thead>
  <tbody>
    
  
        
<?php


$searchQuery = "SELECT Ranking, UNI_Name, Prog_Name FROM programs p join university u ON p.UNI_ID = u.UNI_ID JOIN fields f ON p.FID = f.FID where Field_Name = '$fieldname' AND Prog_Name = '$progname' AND City_Name = '$cityname' AND Ed_Level = '$edlevel';";

$result = mysqli_query($conn,$searchQuery);
$resultCheck = mysqli_num_rows($result);

if ($resultCheck > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr class="table-success"><td class="bg-warning">' . $row["Ranking"] . '</td><td class="bg-danger">' . $row["UNI_Name"] . '</td><td class="bg-info">' . $row["Prog_Name"] . '</td><td class="bg-success">' . '<a class = "btn btn-primary" href="ProgDetails.php?id='.$row['UNI_Name'].'">Details </a>'.'</td></tr>';
    }
    echo "</table>";
    
}
else {
    echo '<script language="javascript">';
    echo 'if (confirm("No Match Found!")) {
            window.location.href = "SearchPage.php";
            }';
    echo '</script>';
}


?>

<a class = "btn btn-primary" href = "SearchPage.php"> Search Again </a>
</tbody>
</table>
</div>
    </div>

</body>
</html>