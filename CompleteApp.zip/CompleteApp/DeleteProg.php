<?php


include_once 'connection.php';

session_start();

    $id = null;

    if(!empty($_GET['id'])){
        $id = $_REQUEST['id']; //selected row for deletion

    }

    //echo "$id";

    $sql = "DELETE from saved_data where sid = '$id';";

    mysqli_query($conn,$sql);
    //mysqli_close($con);
    header("Location: Favourite.php");
?>