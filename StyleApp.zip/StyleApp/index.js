function toggleSidebar(ref){
  document.body.classList.toggle('sidebar-active');
}


