<?php

include_once 'connection.php';
   
$uniName = $_POST['insName'];
$uniCity = $_POST['insCity'];
$uniRanking = $_POST['insRanking'];
$uniContactNo = $_POST['insContactNo'];

$sql = "INSERT INTO university (UNI_Name,Ranking,Contact_Number,City_Name) VALUES ('$uniName','$uniRanking','$uniContactNo','$uniCity');";

mysqli_query($conn,$sql);

echo "$uniName";
echo "$uniCity";
echo "$uniRanking";
echo "$uniContact";

header("Location: ../WebApp/EditUni.php?Insert=success");

?>