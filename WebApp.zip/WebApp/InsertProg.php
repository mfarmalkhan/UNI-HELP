
<html>

<?php

include_once 'connection.php';

$progname = $_GET['progname'];
$proguni = $_GET['uniOptions'];
$progfield = $_GET['fieldOptions'];
$proglevel = $_GET['proglevel'];
$progcriteria = $_GET['criteria'];

$query1 = "INSERT INTO programs (FID, UNI_ID, Prog_Name, Ed_Level, Adm_Criteria) VALUES ((SELECT FID FROM fields WHERE Field_Name = '$progfield'), (SELECT UNI_ID from university where UNI_Name = '$proguni'),'$progname', '$proglevel', '$progcriteria');";

mysqli_query($conn,$query1);

header("Location: ../WebApp/EditPrograms.php?Insert=success");
?>


</html>