<?php

include_once 'connection.php';

$fieldname = $_GET['fieldOptions'];
$uniname = $_GET['uniOptions'];

if ($_GET["update"]) {

$query1 = "INSERT INTO field_offered (FID, UNI_ID) VALUES ((SELECT FID FROM fields WHERE Field_Name = '$fieldname'), (SELECT UNI_ID from university where UNI_Name = '$uniname'));";

mysqli_query($conn,$query1);

}

else if ($_GET["delete"]) {

    $query2 = "DELETE FROM field_offered where FID = (SELECT FID FROM fields WHERE Field_Name = '$fieldname') AND UNI_ID = (SELECT UNI_ID from university where UNI_Name = '$uniname');";
    mysqli_query($conn,$query1);

}

header("Location: ../WebApp/EditFields.php?Edit=success");

?>