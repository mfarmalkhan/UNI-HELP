<?php

include 'connection.php';

$id = $_POST['id'];
$pass = $_POST['password'];

if ($id !== "admin" || $pass !== "admin1234") {
    header("Location: ../WebApp/AdminPanel.php");
}
    else {
        header("Location: ../WebApp/EditRecords.php");
    }

?>