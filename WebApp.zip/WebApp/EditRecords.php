<?php

include 'connection.php';

?>

<html>

<head> 
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

  <style>
    body {
background-image: url('plain.jpg');
}

    </style>
</head>


<body>

<h1 align = "center"> UNI-HELP </h1>


  <br><br><br><br>

    <div class = container style="border: thin solid black">

    

<h2>EDIT PROJECT RECORDS</h2><br><br>

<ul style="list-style-type:disc">
  <li> <a href = "EditUni.php" target="_blank">UPDATE UNIVERSITIES</a></li><br><br>
  <li><a href = "EditFields.php" target="_blank">UPDATE FIELDS</a></li><br><br>
  <li><a href = "EditPrograms.php" target="_blank">UPDATE PROGRAMS</a></li><br><br>
</ul>  

<a class="btn btn-danger" href = "AdminPanel.php"> Log Out </a> <br> <br>

</div>

</body>
</html>