<?php

include_once 'connection.php';

$uniName = $_GET['uniOptions'];
$uniCity = $_GET['editcity'];
$uniRanking = $_GET['editranking'];
$uniContact = $_GET['editcontact'];

if ($_GET["update"]) {

    $query1 = "UPDATE university set City_Name = $uniCity, Ranking = '$uniRanking' where UNI_Name = '$uniName';";
    
    mysqli_query($conn,$query1);
    
    }
    
    else if ($_GET["delete"]) {
    
        $query2 = "DELETE FROM university where UNI_ID = (SELECT UNI_ID from university where UNI_Name = '$uniName');";
        mysqli_query($conn,$query1);
    
    }
    
    header("Location: ../WebApp/EditPrograms.php?Edit=success");

?>