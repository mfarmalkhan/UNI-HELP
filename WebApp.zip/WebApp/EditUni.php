<html>

<head>

<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
    
    <h1 align = "center"> Universities </h1>
    
    
    <body>

        <div class = "container">    
        <form action = "InsertUni.php" method = "POST">
  
            <fieldset>
      
    <legend><b>Insert New</b></legend>
    
      Univerisity Name:<br>
    
      <input type="text" name="insName"><br>
                
      City:<br>
    
      <input type="text" name="insCity"><br>
                
      Ranking:<br>
    
      <input type="number" name="insRanking"><br>
    
      Contact Number:<br>
    
      <input type="text" name="insContactNo"><br><br>
    
      <button type = "submit" name = "submit"> Insert </button>
  
            </fieldset>

        </form>
        </div>

        
        <div class = "container">
            
            <form action = "UpdateUni" method = "POST">
                
                <fieldset>
                    
                <legend><b>Update Records</b></legend>
                
                Select University:
                
                <select name = "uniOptions">
         
          <?php include 'connection.php'; 
          $query = "Select * from university;";


          $result = mysqli_query($conn,$query);
          
          ?>

          <?php while ($row = mysqli_fetch_array($result)):; ?>
          <option value = "<?php echo $row['UNI_Name'];?>"> <?php echo $row['UNI_Name']; $selectedUni = $row['UNI_Name']; ?> </option>
        
            <?php endwhile; ?>

        </select>
                <br><br>
                
                
                 City:
                <input type = "text" name = "editcity"><br><br>
                
                 Ranking:
                <input type = "number" name = "editranking"><br><br>
                
                 Contact Number:
                <input type = "text" name = "editcontact"><br><br>
                
                <button type = "submit" value = "update"> Update </button>
                
                <button type = "submit" value = "delete"> Delete </button>
                    
                    </fieldset>
                
                
            </form>
        
        </div>
        
    
    </body>
</html>