<?php

include_once 'connection.php';

$progname = $_GET['progOptions'];
$proguni = $_GET['uniOptions'];
$progfield = $_GET['fieldOptions'];
$proglevel = $_GET['levelOptions'];
$progcriteria = $_GET['criteria'];

if ($_GET["update"]) {

    $query1 = "UPDATE programs set FID = (SELECT FID FROM fields WHERE Field_Name = '$progfield'), UNI_ID = (SELECT UNI_ID from university where UNI_Name = '$proguni'), Ed_Level = '$proglevel', Adm_Criteria = '$progcriteria' where Prog_Name = '$progname';";
    
    mysqli_query($conn,$query1);
    
    }
    
    else if ($_GET["delete"]) {
    
        $query2 = "DELETE FROM programs where FID = (SELECT FID FROM fields WHERE Field_Name = '$progfield') AND UNI_ID = (SELECT UNI_ID from university where UNI_Name = '$proguni') AND Ed_Level = '$proglevel';";
        mysqli_query($conn,$query1);
    
    }
    
    header("Location: ../WebApp/EditPrograms.php?Edit=success");

?>