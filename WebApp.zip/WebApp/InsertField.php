<?php

include_once 'connection.php';

$fieldname = $_GET['insfieldname'];
$uniname = $_GET['uniOptions'];

$query1 = "INSERT INTO fields (Field_Name) VALUES ('$fieldname')";

mysqli_query($conn,$query1);

header("Location: ../WebApp/EditFields.php?Insert=success");

?>

