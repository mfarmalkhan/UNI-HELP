<html>

<head>

<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
    
    <h1 align = "center"> Education Fields </h1>
    
    <body>
        
    <div class = "container">    
        <form action = "InsertField.php" method = "GET" >
  
            <fieldset>
      
    <legend><b>Insert New</b></legend>
    
      Field Name:<br>
    
      <input type="text" name="insfieldname"><br><br>

                          
<button type = "submit" name = "submit"> Insert </button>
  
            </fieldset>

        </form>
        </div>

       

        <div class = "container">

         <h3><b> Update Records </b></h3>

            <form action = "UpdateFields.php" method = "GET">

            <select name = "fieldOptions">
          <option value = "Select Field" selected> Select Field </option>
          <?php include 'connection.php'; 
          $query = "Select * from fields;";

          $result = mysqli_query($conn,$query);
          
          ?>

          <?php while ($row = mysqli_fetch_array($result)):; ?>
          <option value = "<?php echo $row['Field_Name'];?>"> <?php echo $row['Field_Name']; ?> </option>
        <?php endwhile; ?>

        </select>

            <select name = "uniOptions">
          <option value = "Select University" selected> Select University </option>
          <?php include 'connection.php'; 
          $query = "Select * from university;";

          $result = mysqli_query($conn,$query);
          
          ?>

          <?php while ($row = mysqli_fetch_array($result)):; ?>
          <option value = "<?php echo $row['UNI_Name'];?>"> <?php echo $row['UNI_Name'];?> </option>
        <?php endwhile; ?>

        </select>

        <button type = "submit" name = "submit" value = "update">  Update </button>
        <button type = "submit" name = "submit" value = "delete">  Delete </button>
</form>
</form>

</div>


    
</body>
</html>