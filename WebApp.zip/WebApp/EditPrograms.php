<html> 

<head>

<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
    
    <h1 align = "center"> Programs </h1>
    
    
    <body>
        
        <div class = "container">
    <div class = "form-group">    
        <form action = "InsertProg.php" method = "GET">
  
            <fieldset>
      
    <legend><b>Insert New</b></legend>
    
      Program Name:

      <input type="text" name="progname"><br><br>
                
            Which Field:
            
            <select name = "fieldOptions">
            <option value = "Select Field" selected> Select Field </option>
            <?php include 'connection.php'; 
            $query = "Select * from fields;";

            $result = mysqli_query($conn,$query);
          
          ?>

            <?php while ($row = mysqli_fetch_array($result)):; ?>
            <option value = "<?php echo $row['Field_Name'];?>"> <?php echo $row['Field_Name']; ?> </option>
            <?php endwhile; ?>
                    
                </select> <br><br>
                
                 Which Level:
                 <input type="text" name="proglevel"><br><br>
                
                 Offered In:

                <select name = "uniOptions">
                <option value = "Select University" selected> Select University </option>
                <?php include 'connection.php'; 
                $query = "Select * from university;";

                $result = mysqli_query($conn,$query);

                ?>

                <?php while ($row = mysqli_fetch_array($result)):; ?>
                <option value = "<?php echo $row['UNI_Name'];?>"> <?php echo $row['UNI_Name'];?> </option>
                <?php endwhile; ?>

                </select>
                <br><br>
                    
                Add Admission Criteria: <br><br>
                
                    <!--<input type = "text" name = "criteria"> <br><br>!-->
                    <textarea type = "text" name = "criteria" rows = "3" cols = "80"> </textarea> <br><br>

                    
      <input type="submit" value="Insert">
  
            </fieldset>

        </form>
        </div>
        </div>

         <div class = "container">
            
            <form action ="UpdateProg.php" method = "GET">
                
                <fieldset>
                    
                <legend><b>Update Records</b></legend>
                
                Select Program:
                
            <select name = "progOptions">
            <option value = "Select Field" selected> Select Program </option>
            <?php include 'connection.php'; 
            $query = "Select distinct Prog_Name from programs;";

            $result = mysqli_query($conn,$query);
          
          ?>

            <?php while ($row = mysqli_fetch_array($result)):; ?>
            <option value = "<?php echo $row['Prog_Name'];?>"> <?php echo $row['Prog_Name']; ?> </option>
            <?php endwhile; ?>
                    
                </select>
                
                <br><br>
                
                
                 Which Field:
                 <select name = "fieldOptions">
            <option value = "Select Field" selected> Select Field </option>
            <?php include 'connection.php'; 
            $query = "Select * from fields;";

            $result = mysqli_query($conn,$query);
          
          ?>

            <?php while ($row = mysqli_fetch_array($result)):; ?>
            <option value = "<?php echo $row['Field_Name'];?>"> <?php echo $row['Field_Name']; ?> </option>
            <?php endwhile; ?>
                    
                </select>  <br><br>
                
                 Which Level:
                 <select name = "levelOptions">
            <option value = "Select Field" selected> Select Education Level </option>
            <?php include 'connection.php'; 
            $query = "Select distinct Ed_Level from programs;";

            $result = mysqli_query($conn,$query);
          
          ?>

            <?php while ($row = mysqli_fetch_array($result)):; ?>
            <option value = "<?php echo $row['Ed_Level'];?>"> <?php echo $row['Ed_Level']; ?> </option>
            <?php endwhile; ?>
                    
                </select>  <br><br>
                
                 Offered In:
                 <select name = "uniOptions">
                <option value = "Select University" selected> Select University </option>
                <?php include 'connection.php'; 
                $query = "Select * from university;";

                $result = mysqli_query($conn,$query);

                ?>

                <?php while ($row = mysqli_fetch_array($result)):; ?>
                <option value = "<?php echo $row['UNI_Name'];?>"> <?php echo $row['UNI_Name'];?> </option>
                <?php endwhile; ?>

                </select> <br><br>
                    
                Update Admission Criteria: <br><br>
                    
                <textarea type = "text" name = "criteria" rows = "3" cols = "80"> </textarea><br><br>
                
                <button type = "submit" value = "update"> Update </button>
                
                <button type = "submit" value = "delete"> Delete </button>
                    
                    </fieldset>
                
                
            </form>
        
        </div>
    
    </body>
</html>